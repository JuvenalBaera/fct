import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.sql.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws SQLException {
        // TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        System.out.println("MDE Lab1 - Welcome to the Java Project");

        //Database information
        String url = "jdbc:mysql://192.168.1.67/test?useSSL=false";
        String username = "testuser";   //Replace with your database username
        String password = "test";       //Replace with user password

        //For testing only the MQTT connection, comment until start the MQTT part
        //Test database integration
        try {
            //Start Connection
            Connection conn = MySQL_Integration.createConnection(url,username,password);
            //Execute Query
            ResultSet resultSet = MySQL_Integration.executeQuery(conn, "SELECT * FROM customers");
            //Process Result
            while (resultSet.next()) {
                //Process the result set
                System.out.println(resultSet.getString("id") + "\t" + resultSet.getString("name"));
            }
            //Close Connection
            MySQL_Integration.closeConnection(conn);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        //MQTT Broker information
        //ATTENTION!!!
        //Comment the following line for testing WITHOUT real data
        String broker = "tcp://192.168.250.201:1883";

        //Start Subscription
        //ATTENTION!!!
        //Comment the following line for testing WITHOUT real data
        MQTTLibrary.createSubscriber(broker);
    }

    public static void messageReceived(String topic, MqttMessage message) {
        System.out.println("Message arrived. Topic: " + topic + " Message: " + message.toString());
    }
}